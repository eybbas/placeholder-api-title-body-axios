import './Home.css'

function Home(){
    return(
        <span>Home</span>
    )
}

export {Home};