import './About.css'

function About(){
    return(
        <span>About</span>
    )
}

export {About};