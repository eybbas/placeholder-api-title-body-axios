import React, { createContext, useState } from 'react';
import ReactDOM from 'react-dom';
import './index.css'
import Profile from './components/Profile';
import Posts from './components/Posts';
import Bottom from './components/Bottom';
import Menu from './components/Menu';

function App(){
  return(
    <>
        <Menu/>
        <Profile/>
        <Posts/>
        <Bottom/>
    </>
  )
}

const root = document.getElementById("root");
ReactDOM.render(<App />, root);
