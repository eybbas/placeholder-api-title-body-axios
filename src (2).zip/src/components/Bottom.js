import { createContext, useState } from "react";

const ThemeContext = createContext();

function Bottom(){
    const [theme, setTheme] = useState("light")

    const selectTheme = () => {
        setTheme((prev) => (prev === 'light'? 'dark' : 'light'));
        console.log(theme);
    }

    return(
        <ThemeContext.Provider value={theme}>
            <div>
                <div className="bottom-div">
                    <span className="bottom-span">satellite.inc</span>
                    <span className="bottom-span">Information</span>
                    <span className="bottom-span">Contact Us</span>
                    <span className="bottom-span">Questions</span>
                    <span className="bottom-span">Ideas</span>
                    <span className="bottom-span">Verification</span>
                    <span className="bottom-span">Privacy</span>
                    <span className="bottom-span">API</span>
                    <span className="bottom-span">Help</span>
                    <span className="bottom-span">Locations</span>
                    <span className="bottom-span">About</span>
                    <span className="bottom-span">© 2024 NutY from satellite.inc</span>
                </div>
                <div className="bottom-theme-div">
                    <input className="bottom-theme-radio" type="radio" name="radio" onChange={selectTheme}/>
                    <input className="bottom-theme-radio" type="radio" name="radio" onChange={selectTheme}/>
                </div>
            </div>
        </ThemeContext.Provider>
    )
}
export default Bottom;