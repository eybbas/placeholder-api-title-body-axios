function Posts(){
    return(
        <div className="posts-div">
            <div className="posts-title-div">
                <span className="posts-title-span">Posts:</span>
            </div>
            <div className="posts-content-div">
                <span className="posts-content-span">
                    <img className="posts-content-img" src="https://i.pinimg.com/564x/5a/44/a5/5a44a529c454f95d7f0ef0a31b3a992b.jpg"/>
                </span>
                <span className="posts-content-span">
                    <img className="posts-content-img" src="https://i.pinimg.com/564x/ea/72/01/ea7201d0d30b39b2173c3283d38de325.jpg"/>
                </span>
                <span className="posts-content-span">
                    <img className="posts-content-img" src="https://i.pinimg.com/564x/d4/dc/e8/d4dce8e351a06695b1015c3d49e78f62.jpg"/>
                </span>
                <span className="posts-content-span">
                    <img className="posts-content-img" src="https://i.pinimg.com/236x/9f/ae/58/9fae58076426ba0b0b4def03cf007571.jpg"/>
                </span>
            </div>
            <div className="posts-bottom-div">
            </div>
        </div>
        
    )
}
export default Posts