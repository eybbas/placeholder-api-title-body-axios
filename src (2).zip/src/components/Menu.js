import { useContext } from "react";
import ThemeContext from "./Bottom"

function Menu(){
    const theme = useContext(ThemeContext);
    console.log(theme);
    return(
        <div className="menu-div">
            <div className="menu-logo-div">
                <label className="menu-logo-img"></label>
                <span className="menu-logo-title">NutY.com</span>
            </div>
            <ul className="menu-btn-ul">
                <li className="menu-btn">Profile</li>
                <li className="menu-btn">Messenger</li>
                <li className="menu-btn">Active</li>
            </ul>
        </div>
    )
}
export default Menu;