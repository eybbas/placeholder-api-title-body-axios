function Profile(){
    return(
        <div className="profile-div">
            <div className="profile-picture-div">
                <span className="profile-picture-span">
                    <img className="profile-picture-img" src="https://i0.wp.com/digitalhealthskills.com/wp-content/uploads/2022/11/fd35c-no-user-image-icon-27.png?fit=500%2C500&ssl=1"/>
                </span>
            </div>
            <div className="profile-info-btn-div">
                <div className="profile-name-div">
                    <span className="profile-name-span">@sxtell</span>
                    <div className="profile-pro-div">
                        <span className="profile-pro-span">Photographer</span>
                    </div>
                </div>
                <div className="profile-info-div">
                    <span className="profile-posts-span">4 Posts</span>
                    <span className="profile-subscribers-span">450 Subscribers</span>
                    <span className="profile-subscriptions-span">40 Subscriptions</span>
                </div>
                <div className="profile-btn-div">
                    <button className="profile-edit-btn">Edit Profile</button>
                    <button className="profile-archive-btn">Archive</button>
                    <button className="profile-project-btn">Projects</button>
                </div>
            </div>
        </div>
    )
}
export default Profile